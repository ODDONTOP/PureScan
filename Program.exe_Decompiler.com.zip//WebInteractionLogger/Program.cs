using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;

namespace WebInteractionLogger;

internal class Program
{
	private static readonly string logFilePath = "file_upload_log.txt";

	private static readonly string websiteUrl = "https://purescan.godaddysites.com/";

	private static void Main(string[] args)
	{
		Console.WriteLine("Launching " + websiteUrl);
		OpenWebsite(websiteUrl);
		Console.WriteLine("Starting local server to listen for file uploads...");
		StartLocalServer();
	}

	private static void OpenWebsite(string url)
	{
		Process.Start("termux-open", url);
	}

	private static void StartLocalServer()
	{
		HttpListener httpListener = new HttpListener();
		httpListener.Prefixes.Add("http://localhost:5000/");
		httpListener.Start();
		Console.WriteLine("Listening for file data on http://localhost:5000/");
		while (true)
		{
			try
			{
				HttpListenerContext context = httpListener.GetContext();
				HttpListenerRequest request = context.Request;
				using (StreamReader streamReader = new StreamReader(request.InputStream, request.ContentEncoding))
				{
					string text = streamReader.ReadToEnd();
					LogEvent("Received file information: " + text);
					Console.WriteLine("File info received: " + text);
				}
				HttpListenerResponse response = context.Response;
				string s = "File information received successfully!";
				byte[] bytes = Encoding.UTF8.GetBytes(s);
				response.ContentLength64 = bytes.Length;
				response.OutputStream.Write(bytes, 0, bytes.Length);
				response.OutputStream.Close();
			}
			catch (Exception ex)
			{
				LogEvent("Error: " + ex.Message);
				Console.WriteLine("Error: " + ex.Message);
			}
		}
	}

	private static void LogEvent(string message)
	{
		string text = $"{DateTime.Now:G} - {message}";
		File.AppendAllText(logFilePath, text + Environment.NewLine);
		Console.WriteLine(text);
	}
}
